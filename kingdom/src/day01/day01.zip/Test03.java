package day01;

public class Test03 {
	public static void main(String [] args) {
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!");
		System.out.println("오늘 날씨 너무 좋아요!1");
		System.out.println("오늘 날씨 너무 좋아요!2");
	}

}
