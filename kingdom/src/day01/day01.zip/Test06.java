package day01;

public class Test06 {
	public static void main(String[] args) {
		/*
		 * 자동형변환
		 */
		
		char ch = 'A';
		int no1 = 'A'+10;
		
		int no2 = 'Z';
		
		double no3 = no1;
		double no4 = 'C';
		
		/*
		 * 	참고 ]
		 * 		타입이 다른 데이터의 연산 결과는
		 * 		타입이 큰쪽의 데이터타입으로 결정된다.
		 */
	}
}
