package day01;

public class Test02 {
	static int no1=10;
	void abc() {
	}
	
	public static void main(String [] args) {
		System.out.println("no1 : "+ no1);
	}
}
