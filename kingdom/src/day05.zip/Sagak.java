package day05;

public class Sagak {
	int garo,sero;
	int arr,area;
	
	void getValue() {
		garo = (int)(Math.random()*21)+5;
		sero = (int)(Math.random()*21)+5;
		arr = (garo+sero)*2;
		area = garo*sero;
	}
 	
	void printSagak() {
		System.out.printf("사각형 가로의 길이:	%2d	세로의 길이:	%2d"
				+ "	둘레:	%d	넓이:	%d\n",garo,sero,arr,area );
	}

}
