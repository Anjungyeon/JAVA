package day05;

import java.util.Scanner;

public class Ex07 {
/*
 	학생의 java,db,js,jsp,spring 과목을 관리할 클래스를 제작하세요
 	총점 평균 원하면 볼 수 있어야한다.
 	
 	5명의 학생들의 점수를 관리할 배열을 만들고 정보를 출력.
 	학생번호 입력하게해서 
 	학생번호를 입력하면 배열에서 해당학생의 정보를 꺼내서 보여주는 프로젝트
 	
 	extra ]
 	석차도 입력해서 정보꺼내기
 */
	public static void main(String[] args) {
		Student st[] = new Student[5];
		int num;
		for(int i=0;i<st.length;i++) {
			st[i] = new Student();
			num = (int)(Math.random()*901)+100;
			st[i].setInformation(num); // ID = 1,2,3,4,5 로 자동 셋팅
			st[i].setScore();
		}
		
		/*for(Student read:st) {
				read.printScore();
		}*/
		for(int i=0;i<st.length;i++) {
			for(int j=0;j<st.length;j++) {
				if(st[i].sum<st[j].sum) {
					st[i].grad++;
				}				
			}
		}
		/*
		for(Student test:st) {
			test.printScore();
			System.out.println(test.grad+"등");
		}*/
		
		int id;
		System.out.println("점수를 알고싶은 학생의 ID나 등수를 입력하세요");
		System.out.print("저장되어있는 학생의 ID : ");
		for(int i=0;i<st.length;i++) {
			System.out.print(st[i].id+" ");
		}
		System.out.println();
		Scanner sc = new Scanner(System.in);
		id = sc.nextInt();
		sc.close();
		for(Student read:st) {
			if(id == read.id) {
				read.printScore();
			}
			else if(read.grad==id) {
				read.printScore();
			}
		}
	}

}
