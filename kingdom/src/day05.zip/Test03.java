package day05;

public class Test03 {

	public static void main(String[] args) {
		// 반지름이 5 ~ 25 사이의 값을 갖는 원을 만들어서 정보를 출력해보쟝!!!!!!!!!!!!!!!!!!
		
		Won c1 = new Won(); // 객체 생성,Object 생성
		
		// 반지름 대입
		
		int r = (int)(Math.random()*21)+5;
		c1.setRad(r);
		c1.setCir();
		c1.setArea();
		c1.printWon();

	}

}
