package day05;

public class Test02 {
	void sagakClac(int a, int b) {
		int area = a*b;
		System.out.printf("가로 : %3d\n세로 : %3d\n넓이 : %3d", a,b,area);
		
	}
	/*
	 	가로 세로를 입력하면
	 	사각형의 넓이를 계산해서
	 		"가로 : XXX,
	 		 세로 : XXX,
	 		 넓이 : XXX
	 		"
	 	의 형태로 출력해주는 함수를 작성하고 실행하세요.
	 	단 실행할때 입력할 데이터는 5~25사이의 정수로 랜덤하게 만들어서 실행하세요.
	 */
	public Test02() {
		int a = (int)(Math.random()*21+5);
		int b = (int)(Math.random()*21+5);
		sagakClac(a,b);
		
	}
	

	public static void main(String[] args) {
		new Test02();
	}

}
