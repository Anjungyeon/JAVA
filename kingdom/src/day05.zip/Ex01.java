package day05;

public class Ex01 {
	/*
	반지름(5 ~ 25) 하나를 랜덤하게 입력하면
	원의 넓이와 둘레를 계산해서 출력해주는 프로그램을 작성하세요.
	
	단, 넓이와 둘레계산은 각각의 함수에서 처리하는 것으로 한다.
 */
	//넓이계산
	double area(int r) {
		double area = 0;
		area = r*2*3.14;
		return area;
	}
	//둘레계산
	double cir(int r) {
		double cir = 0 ;
		cir = r*r*3.14;
		return cir;
	}
	
	public Ex01() {
		int r = (int)(Math.random()*21)+5;
		double area1 = area(r);
		double cir1 = cir(r);
		System.out.printf("반지름 : %d\n둘레 : %.2f\n넓이 : %.2f", r,area1,cir1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Ex01();

	}

}
