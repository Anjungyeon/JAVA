package day05;

public class Won {
	//변수선언
	int rad;	// 객체가 되는 순간 0으로 자동 초기화가 된다.
	double cir;	// 0.0 으로 자동 초기화
	double area;
	final double PI = 3.14;
	
	// 반지름을 기억시켜주는 기능의 함수
	void setRad(int r) {
		// 반지름 변수에 입력받은 데이터 대입
		rad = r;
		return; // 생략 가능
	}
	// 둘레를 계산하는 함수
	void setCir() {
		cir = rad*2*PI;
		return;
	}
	// 넓이를 계산하는 함수
	void setArea() {
		area = rad*rad*PI;
		
	}
	// 원의 정보를 출력해주는 함수
	void printWon() {
		System.out.printf("원의 반지름 : %2d		둘레 : %.3f		넓이 : %.3f\n",rad,cir,area);
	}

}
