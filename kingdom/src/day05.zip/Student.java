package day05;

public class Student {
	/*
 	학생의 java,db,js,jsp,spring 과목을 관리할 클래스를 제작하세요
 	총점 평균 원하면 볼 수 있어야한다.
 	
 	5명의 학생들의 점수를 관리할 배열을 만들고 정보를 출력.
 	학생번호도 입력하게해서 
 	학생번호를 입력하면 배열에서 해당학생의 정보를 꺼내서 보여주는 프로젝트
 */
	
	int java,db,js,jsp,spring;
	int sum,id;
	double avg;
	int grad=1;
	
	void setInformation(int num) {
		id = num;
		java= (int)(Math.random()*61)+40;
		db= (int)(Math.random()*61)+40;
		js= (int)(Math.random()*61)+40;
		jsp= (int)(Math.random()*61)+40;
		spring= (int)(Math.random()*61)+40;		
	}
	void setScore() {
		sum = java+db+js+jsp+spring;
		avg = sum/5;
	}


	void printScore() {
		
		System.out.printf("ID :%d	|java : %3d점	db : %3d점	js : %3d점	jsp : %3d점	spring : %3d점"
				+ "\n	|총점 : %d점	평균 : %.2f점	등수 : %d등\n",
							id,java,db,js,jsp,spring,sum,avg,grad);		

	}
}
