package day05;

public class Test04 {
	/*
	 	Won 클래스를 이용해서 원의 정보를 4개 관리하는 배열 만들고
	 	랜덤하게 반지름을 입력해서 다른정보들도 다 출력해보쟈요!!!!!!!!!!
	 */

	public static void main(String[] args) {
		Won t[] = new Won[5];
		
		// Won 객체를 채워준다
		for(int i=0;i<t.length;i++) {
			t[i] = new Won();
		}
		// 정보 입력하기
		for(int i=0;i<t.length;i++) {
			t[i].rad = (int)(Math.random()*21)+5;
			//t[i].setCir();
			//t[i].setArea();
		}
		// 이렇게도 사용 가능!!
		for(Won read:t) {
			read.setCir();
			read.setArea();
		}
		for(Won read:t) {
			read.printWon();
		}

	}

}
