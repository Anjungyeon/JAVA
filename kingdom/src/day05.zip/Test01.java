package day05;

public class Test01 {
/*
 	정수를 입력하면 정수를 문자열로 변환시켜서 반호나해주는 함수를 만들기
 	
	함수이름은 add를 사용
 	
 	참고 ]
 		함수를 제작하는 위치는 클래스 블럭 하위에 위치해야만한다.
		-> 함수 내부에 함수를 만들 수 없다. 
 */
	
	public Test01() { // 생성자
		add(123); 
		String atr = add(123);
		
		System.out.println(add(123));
	}
	String add(int a) {
		String str = a + "";// 타입이 큰 쪽으로 따라가니까 정수가 문자열로 바뀐다
		return str;
		
		// return a+""; // 한줄로도 가능
	}
	
	public static void main(String[] args) {
		new Test01();

	}

}
