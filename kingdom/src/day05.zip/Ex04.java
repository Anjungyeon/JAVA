package day05;

public class Ex04 {
	/*
	 	Ex03문제와 같이 Samgak 형 클래스를 제작하고
	 	삼각형 한개의 정보를 출력하세요.
	 */

	public static void main(String[] args) {
		Samgak sam = new Samgak();
		sam.getValue();
		sam.printSagak();
		
	}

}
