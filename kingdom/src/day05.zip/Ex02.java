package day05;

import java.util.Arrays;
import java.util.Scanner;

public class Ex02 {
	/*
	 1차원 배열에 10개의 데이터를 입력한 후 
	 총점과 평균을 구하는 프로그램 작성.
	 단, 점수입력, 총점계산, 평균계산은 각각 함수에서 처리.
	 
	 extra ]
	 	숫자를 입력해서 실행하면 해당길이의 숫자길이를 가지는 배열만들고 실행
*/
	//점수입력해주는 함수
	int[] wScore(int score[]) {
		for(int i=0;i<score.length;i++) {
			score[i] = (int)(Math.random()*71)+30;
		}
		return score;
	}

	//총점계산해주는 함수
	double sum(int score[]) {
		double sum=0;
		for(int i=0;i<score.length;i++) {
			sum = sum + score[i];
		}
		return sum;
	}

	//평균계산해주는 함수
	double avg(int score[]) {
		double sum=0;
		for(int i=0;i<score.length;i++) {
			sum = sum + score[i];
		}
		return sum/score.length;
	}
	
	public Ex02(){
		Scanner sc = new Scanner(System.in);
		int score[] = new int[sc.nextInt()];
		sc.close();
		
		
		score = wScore(score);
		double sumS =sum(score);
		double avgS =avg(score);
		
		System.out.println("점수 : "+ Arrays.toString(score));
		System.out.printf("총점 : %.2f\n평균 : %.2f", sumS,avgS);

 	}
	public static void main(String[] args) {
		new Ex02();
		

	}

}
