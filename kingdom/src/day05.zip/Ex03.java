package day05;

public class Ex03 {
	/*
	 	사각형의 정보를 기억할(Sagak)을 만들어서
	 	가로세로를 랜덤하게 입력해서 출력해주는 기능을 가지는 클래스를 제작하세요.

	 */

	public static void main(String[] args) {
		Sagak sq = new Sagak();
		sq.getValue();
		sq.printSagak();

	}

}
