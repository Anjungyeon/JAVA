package day05;

public class Ex05 {
	/*
	 	Ex03 에서 만든 클래스에 사각형 5개를 관리하는 배열을 만들고
	 	데이터를 채워서 출력하세요.
	 */

	public static void main(String[] args) {
		Sagak sag[] = new Sagak[5];
		for(int i=0;i<sag.length;i++) {
			sag[i] = new Sagak();
		}
		for(Sagak read:sag) {
			read.getValue();
			read.printSagak();
		}

	}

}
