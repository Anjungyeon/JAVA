package day05;

public class Samgak {
	int garo,sero;
	double area=0;
	
	void getValue() {
		garo = (int)(Math.random()*21)+5;
		sero = (int)(Math.random()*21)+5;
		area = garo*sero;
	}

	void printSagak() {
		System.out.printf("삼각형 가로의 길이:	%2d	세로의 길이:	%2d 넓이:	%.2f\n",garo,sero,area/2);
	}

}
