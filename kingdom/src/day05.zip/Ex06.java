package day05;

public class Ex06 {
	/*
 	Ex04 에서 만든 클래스에 삼각형 5개를 관리하는 배열을 만들고
 	데이터를 채워서 출력하세요.
 */
	public static void main(String[] args) {
		Samgak sam[] = new Samgak[5];
		for(int i=0;i<sam.length;i++) {
			sam[i] = new Samgak();
		}
		for(Samgak read:sam) {
			read.getValue();
			read.printSagak();
			}

	}

}
