package day04;

public class Ex07 {
	/*
	Test09에서 만든 배열을 
	하나의 배열로 깊은 복사를 해서 만드세요.
	단, System.arraycopy() 를 사용해서 만드세요.
 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
