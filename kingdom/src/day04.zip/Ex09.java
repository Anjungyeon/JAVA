package day04;

public class Ex09 {
	/* 
	 	Ex08 에서 만든 배열을
	 	한과목점수를 기억하는 배열로 변환하세요.
	 	
	 	학생1 | 학생2 | 학생3 | 학생4 | 학생5 | 과목별총점
	 국어
	 영어
	 수학
	 총점
	 
	 	과목별 총점 만들기
	 */

	public static void main(String[] args) {
		int score[][] = new int[4][6];
				
		for(int i=0;i<score.length-1;i++) {
			int subHap = 0;
			for(int j=0;j<score[i].length-1;j++) {
				score[i][j] = (int)(Math.random()*101);	
				subHap = subHap + score[i][j];
				score[i][5] = subHap; 
			}
			
		}
		for(int i=0;i<score[0].length-1;i++)
		{
			int stuHap = 0;
			for(int j=0;j<score.length-1;j++) {
				stuHap = stuHap + score[j][i];
				
				score[3][i] = stuHap;
			}
			
		}
		
		for(int[] read1:score) {
			for(int read2:read1) {
				System.out.print(read2+" 	| 	");
				
			}
			System.out.println();
		}

	}

}
