package day04;

public class Ex02 {

	public static void main(String[] args) {
		/*
		 	알파벳 5개를 랜덤하게 추출해서 배열에 기억하세요.
		 	단, 중복문자는 없어야됨!
		 */
		
		char ch[] = new char[5];
		for(int i=0;i<ch.length;i++) {
			//ch[i]=(char)(int)(Math.random()*26+65);
			ch[i]=(char)(int)(Math.random()*('Z'-'A'+1)+'A');
			for(int j=0;j<i;j++) {
				if(ch[i]==ch[j]) {
					i--;
					break;
				}
			}
		}
		for(char ch1:ch) {
			System.out.println(ch1);
		}
		System.out.println(new String(ch));

	}

}
