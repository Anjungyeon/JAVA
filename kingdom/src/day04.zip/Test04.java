package day04;

public class Test04 {

	public static void main(String[] args) {
		/*
		 	1 ~ 45 까지의 숫자 6개를 중복되지 않도록 만들어서
		 	배열에 기억시키고 오름차순으로 정렬하고 출력하세요
		 */
		
		int lotto[] = new int[6];
		int tmp=0;
		/*
		 	참고 ] 
		 		배열의 길이 알아내는 방법
		 		 --> 배열.length
		 */
		
		for(int i=0;i<lotto.length;i++) {
			lotto[i] = (int)(Math.random()*6)+1;
			for(int j=0;j<i;j++) {
				if(lotto[i]==lotto[j]) {
					//중복된경우
					i--;
					break;
				}
			}
		}
		for(int i=0;i<lotto.length-1;i++) {
			for(int j=i+1;j<lotto.length;j++) {
				if(lotto[i]>lotto[j]) {
					tmp = lotto[i];
					lotto[i] = lotto[j];
					lotto[j] = tmp;
				}
			}
		}
		for(int read:lotto) {
			System.out.println(read);
		}
		

	}

}
