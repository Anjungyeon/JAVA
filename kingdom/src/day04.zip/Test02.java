package day04;

public class Test02 {

	public static void main(String[] args) {
		/*
		 	블랙핑크 멤버를 관리할 배열
		 	blackpink를 만들고 
		 	멤버들의 이름을 기억시키세요.
		 	
		 */
		
		// 배열선언과 초기화 동시에하기
		//String blackpink[] ={"리사","제니","로제","지수"};
		String blackpink[]= new String[]{"리사","제니","로제","지수"};
		
		
		for(String member:blackpink) {
			System.out.println(member);
		}
		
		
		String memb1 = new String("제니");
		String memb2 = new String("리사");
		String memb3 = new String("로제");
		String memb4 = new String("지수");
		
		blackpink[1]=memb1;
		blackpink[2]=memb2;
		blackpink[3]=memb3;
		blackpink[4]=memb4;
		
		

	}

}
