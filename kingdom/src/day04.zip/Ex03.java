package day04;

public class Ex03 {
	/*
	 	'A' ~ 'J' 까지의 문자를 랜덤하게 100개 발생한 후
	 	각각의 문자가 몇개씩 만들어졌는지 그래프형태로 출력하세요.
	 	
	 	'A'-'A' 로 인덱스 만들기
	 	cnt[0] -> 'A' 의 갯수 입력
	 	
	 */

	public static void main(String[] args) {
		
		char ch = ' ';
		int cnt[] = new int[10];
		
		for(int i=0;i<100;i++) {
			ch = (char)(int)(Math.random()*('J'-'A'+1)+'A');
			cnt[(int)(ch-'A')] +=1;
		}
		
		/*for(int read:cnt) {
			System.out.println(read);
		}*/
		
		for(int i=0;i<cnt.length;i++) {
			System.out.print((char)(i+'A')+" ");
			for(int j=0;j<cnt[i];j++) {
				System.out.print("■");
			}
			System.out.println();
		}
	

	}

}
