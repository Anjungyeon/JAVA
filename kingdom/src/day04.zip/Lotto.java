package day04;

public class Lotto {
	/*
	 	로또는 한게임에 1000원 지불하고 6개의 1~45 사이 번호로 구성.
	 	로또 한장에는 5게임.
	 	금액을 입력하면 그 금액에 해당하는 로또게임을 만들어주는 프로그램을 작성하세요.
	 	
	 	한 게임당 번호가 오름차순으로 정렬 되어서 출력
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
