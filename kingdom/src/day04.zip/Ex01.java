package day04;

public class Ex01 {

	public static void main(String[] args) {
		/*
		 	6개의 1 ~ 45까지의 정수를 기억할 수 있는 배열을 만들고
		 	서로 다른 정수 6개를 기억시켜서 출력하세요.
		 */
		
		// 1. 배열만들기
		int[] num = new int[6];
		
		//loop:
		for(int i= 0;i<6;i++) {
			num[i] = (int)(Math.random()*45)+1;
			for(int j =0; j<i;j++) { // 중복되는 숫자있는지 비교
				if(num[j]==num[i]) {
					i--;
					break;
					//continue loop;
				}
			}
		}
		
		// 정렬해보깅
		int tmp=0;
		
		for(int i=0;i<num.length-1;i++) {
			for(int j=i+1;j<num.length;j++) {
				if(num[i]>num[j]) {
					tmp = num[i];
					num[i]=num[j];
					num[j]=tmp;
				}
			}
		}
		
		for(int read:num){
			System.out.println(read);
		}

	}

}
