package day04;

public class Ex08 {
	/*
	 	1. 5명학생 국영수 점수 관리 배열
	 	2. 점수랜덤
	 	3. 각학생의 총점
	 	4. 총점이 높은사람순으로 정렬한후 수정하고
	 	5. 출력
	 	
	 	국어 | 영어 | 수학 | 총점
	 1
	 2
	 3
	 4
	 5
	 */

	public static void main(String[] args) {
		
		int score[][] = new int[5][4];
		
		
		for(int i=0;i<score.length;i++) {
			int hap = 0;
			for(int j=0;j<score[i].length-1;j++) {
				score[i][j] = (int)(Math.random()*91)+10;	
				hap = hap + score[i][j];
				score[i][3] = hap; 
			}
			
		}
		int tmpsum = score[0][3];
		int tmp[] = new int[3];
		for(int i=0;i<score.length;i++) {
			if(tmpsum<score[i][3]) {
				System.out.println(tmpsum);
				for(int j=0;j<3;j++) {
					tmp[j] = score[i-1][j];
					score[i-1][j] = score[i][j];
					score[i][j] = tmp[j];
					
				}
				
				tmpsum = score[i][3];	
			}
			
			
		}
		int a=1;
		System.out.println("	국어	|	영어	|	수학	|	총점	|");
		System.out.println("     ------------------------------------------------------------");
		for(int[] read1:score) {
			System.out.printf("학생%d|	", a);
			a++;
			for(int read2:read1) {
				
				System.out.print(read2+"	|	");
				
			}
			System.out.println();
		}

	}

}
