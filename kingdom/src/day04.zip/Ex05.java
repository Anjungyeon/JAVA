package day04;

import java.util.Arrays;

public class Ex05 {
	/*
	 	int[] coin = {10000,5000,1000,500,100,50,10,1}; 
	 	를 준비하고
	 	79456원을 준비된 화폐로 계산할 때 각각의 화폐단위가 몇개가 필요한지를
	 	기억하는 배열을 만들어 기억시키고 출력하는 프로그램.
	 */

	public static void main(String[] args) {
		int[] coin = {10000,5000,1000,500,100,50,10,1}; 
		int[] cnt = new int[coin.length];
		int money = 79456;
		
		for(int i =0;i<coin.length;i++) {
			cnt[i]=money/coin[i];
			money = money - cnt[i]*coin[i];
		}
		
		for(int i =0;i<coin.length;i++) {
			System.out.println(coin[i]+"원은 "+cnt[i]+"개 ");
		}

	}

}
