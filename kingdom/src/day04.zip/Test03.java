package day04;

import java.util.Scanner;

public class Test03 {
	/*
	 	Heap 영역
	 		특징
	 			1. 반드시 주소를 알아야 사용할 수 있는 영역
	 			2. 8가지 영역중에서 크기가 가장 큰 영역이며 확장가능하다.
	 				( 부족하면 스스로 다른영역을 빼앗아서 heap 영역으로 사용할 수 있다.)
	 				==> 
	 					따라서 자바는 많은 양의 데이터가 필요하면
	 					이것은 heap에 기억하도록 되어있다.
	 			3. 원칙적으로 한번 만들어지면 그 프로그램이 종료욀때까지 없어지지않는 영역이다.
	 				(-> 이것때문에 가비지콜렉터라는 말이 생김)
	 		   ***|***
	 			4. heap 영역에 만들어지는 변수는 자동 초기화된다.
	 */

	public static void main(String[] args) {
		/*
		 	문제 ]
		 		1 
		 		길이가 5만큼의 문자데이터를
		 		기억할 수 있는 배열을 만들고 배열에 랜덤하게
		 		해당 갯수만큼 문자를 만들어서 기억시키고 출력하세요.
		 		
		 		2
		 		숫자를 입력받아서 해당 숫자만큼의 문자데이터를
		 		기억할 수 있는 배열을 만들고 배열에 랜덤하게
		 		해당 갯수만큼 문자를 만들어서 기억시키고 출력하세요.
		 */
		// 문제 1 
		char[] ch1 = new char[5];
		for(int i=0;i<ch1.length;i++) {
			ch1[i]=(char)(int)(Math.random()*26+65);
		}
		for(char read:ch1) {
			System.out.print(read+" ");
		}
		
		
		// 문제 2
		Scanner sc = new Scanner(System.in);
		int len = sc.nextInt();
		sc.close();
		
		char[] ch2 = new char[len];
		for(int i=0;i<ch2.length;i++) {
			ch2[i]=(char)(int)(Math.random()*26);
		}
		
		for(char read:ch2) {
			System.out.print(read+" ");
		}
		

	}

}
