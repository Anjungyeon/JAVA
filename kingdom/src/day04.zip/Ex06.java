package day04;

public class Ex06 {
	/*
	 		반지름(int), 둘레, 넓이 (double)를 기억할 배열을 5개의 데이터를 저장할 크기로 만들고
	 		반지름을 랜덤하게 5~ 25사이의 숫자로 추출해서 기억시키고
	 		둘레, 넓이의 배열에 각 반지름에 해당하는 값을 입력하세요.
	 		그리고 출력하세요.
	 */

	public static void main(String[] args) {
		
		int r[] = new int[5];
		double cir[] = new double[5];
		double area[] = new double[5];
		
		for(int i=0;i<r.length;i++) {
			r[i] = (int)(Math.random()*21)+5;
			cir[i] = (2 * 3.14 * r[i]);
			area[i] = r[i]*r[i]*3.14;
		}
		for(int i=0;i<r.length;i++) {
			//System.out.println("반지름이 "+r[i]+"인 원의 둘레는 "+cir[i]+"이고 넓이는 "+area[i]+"입니다.");
			System.out.printf("%-7s : %2d , %-7s : %5.2f, %-7s : %5.2f \n","radius",r[i],"circumference",cir[i],"area",area[i]);
		
		}
		
		


	}

}
