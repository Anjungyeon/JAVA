package day03;

public class Ex02 {
	/*
	 	정수 3개를 랜덤하게 발생시켜서
	 	3개의 숫자가 오름차순으로 정렬되게 출력되게 하세요.
	 */
	public static void main(String[] args) {
		/*int num1 = (int)(Math.random()*100)+1; // 1부터 100까지
		int num2 = (int)(Math.random()*100)+1; 
		int num3 = (int)(Math.random()*100)+1; 
		*/
		
		int num[] = new int[3];
		int tmp = 0;
		
		for(int i=0;i<3;i++) {
			num[i] = (int)(Math.random()*100)+1; 
		}
		
		for(int j=0;j<num.length;j++) {
			for(int k=0;k<num.length-1;k++) {
				if(num[k]>=num[k+1]) {
					tmp = num[k+1];
					num[k+1] = num[k];
					num[k] = tmp;
				}
				
			}
			
			
		}
		System.out.println(num[0]);
		System.out.println(num[1]);
		System.out.println(num[2]);

		
		
	}
}
