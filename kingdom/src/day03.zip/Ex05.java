package day03;
import java.util.Scanner;
public class Ex05 {
	/*
	 	전기요금을 계산해주는 프로그램을 작성하세요.
	 	전기요금은
	 					코드			기본요금			사용요금
	 		가정용			1				3800			245				
	 		산업용			2				2400			157
	 		교육용			3				2900			169
	 		상업용 			4				3200			174
	 		
	 	이런경우 용도와 사용량을 입력하면 전기요금을 계산해주는 프로그램을 작성하세용 >3<
	 		
	 */
	public static void main(String[] args) {
		System.out.print("용도와 사용량을 입력해주세요 1: 가정용, 2: 산업용, 3:교육용, 4: 상업용 ");
		Scanner sc1 = new Scanner(System.in);
		
		Scanner sc2 = new Scanner(System.in);
		
		int purpose = sc1.nextInt();
		int usage = sc2.nextInt();
		int tax = 0;
		
		switch(purpose){
			case 1:
				tax = 3800+(245*usage);
				break;
			case 2:
				tax = 2400+(157*usage);
				break;
			case 3:
				tax = 2900+(169*usage);
				break;
			case 4:
				tax = 3200+(174*usage);
				break;
			default:
				System.out.println("유효하지 않은 숫자입니당 다시입력해쥬세용");
				
			
		}
		System.out.println("사용요금은 "+tax+"원 입니당.");
	}
}
