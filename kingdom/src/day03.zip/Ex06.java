package day03;

import java.util.Scanner;

public class Ex06 {
	/*
 	컴퓨터와 사용자가 가위바위보 게임을 한다.
 	
 	컴퓨터는 랜덤하게 1 ~ 3사이의 숫자를 발생하여 가위, 바위, 보를 만들고
 	사용자는 키보드를 이용해서 1 ~ 3 사이의 숫자를 입력하도록 한다.
 	
 	누가 이겼는지 확인하는 프로그램을 작성하세욧
 	1 : 가위 2: 바위 3: 보
 */
	public static void main(String[] args) {
		
		int num1 = (int)(Math.random()*3)+1;// 컴퓨터가 랜덤으로 뽑은 가위바위보
		System.out.println("1 ~ 3사이의 숫자를 입력하세요 :");
		Scanner sc = new Scanner(System.in);
		int num2 = sc.nextInt();// 사용자한테 입력받은 숫자
		String res = "";
		
		switch(num1) {
			case 1:
				if (num2==num1) {
					res = "무승부";
				}
				else if(num2==2) {
					res = "사용자 승리";
				}
				else {
					res = "컴퓨터 승리";
				}
				break;
			case 2:
				if (num2==num1) {
					res = "무승부";
				}
				else if(num2==3) {
					res = "사용자 승리";
				}
				else {
					res = "컴퓨터 승리";
				}
				break;
			case 3:
				if (num2==num1) {
					res = "무승부";
				}
				else if(num2==1) {
					res = "사용자 승리";
				}
				else {
					res = "컴퓨터 승리";
				}
				break;
		}
		
		System.out.println("컴퓨터 "+num1+" vs "+"사용자 "+num2+"  ====>  "+res);
	}
}
