package day03;
import java.util.Scanner;
public class Ex04 {
	/*
	 	1000 ~ 3000 사이의 년도를 입력하면
		해당 해가 평년인지 윤년인지를 판별해주는 프로그램을 작성하세요.
		
		참고 ]
			윤년은 4로 나누어 떨어지며 100으로 나누어 떨어지는 해는 제외하고
				400으로 나누어 떨어지는 해는 포함시킨다.
	 */
	public static void main(String[] args) {
		System.out.print("1000 ~ 3000 사이 숫자의 년도를 입력하세요 :");
		
		Scanner sc = new Scanner(System.in);
		int year = sc.nextInt();
		String res = "";
		sc.close();
		
		if(year%4==0) {
			if(year%400==0) {
				res = "윤년";
			}
			else if(year%100==0) {
				res = "평년";
			}
			else {
				res = "윤년";
			}
		}
		else {
			res = "평년";
		}
		
		System.out.println("입력하신 "+year+"년은 "+res+"입니다.");
	}

}
