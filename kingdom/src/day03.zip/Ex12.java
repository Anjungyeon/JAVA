package day03;

public class Ex12 {
	
	/*
	1, 1, ...	로 시작하는 피보나치 수열 10개를 출력하세요.
	
	참고 ]
		피보나치수열 : 이전에 만들어진 두 수를 더해서 수를 만들어 나가는 수열
		
			1, 1, 2, 3, 5, 8, ....
*/
	public static void main(String[] args) {
		int num1 = 1;
		int num2 = 1;
		int tmp = 0;
		System.out.print(num1+", "+num2);
		for(int i = 0; i<8;i++) {
			tmp = num1;
			num1 = num2;
			num2 = tmp+num1;
			if(i!=8) {
				System.out.print(", ");
			}
			System.out.print(num2);
		}
			
	}

}
