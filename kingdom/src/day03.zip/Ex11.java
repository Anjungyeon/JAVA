package day03;
import java.util.Scanner;
public class Ex11 {
	/*
	3 ~ 100 사이의 숫자를 입력하면 
	입력받은 숫자가 소수인지 판단하는 프로그램을 작성하세요.
 */
	public static void main(String[] agrs) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt(); // 입력받은 숫자
		int cnt = 1; // 1을 제외한 약수의 개수
		
		sc.close();
		
		for(int i=2;i<num;i++) {
			if(num%i==0) {
				cnt++;
			}
		}
		
		if(cnt == 1) {
			System.out.println("소수입니당");
		}
		else {
			System.out.println("소수가 아닙니당");
		}
		
	}

}
