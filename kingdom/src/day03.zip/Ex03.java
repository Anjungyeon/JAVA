package day03;

public class Ex03 {
	/*
	 	게시판에 게시물을 게시할려고한다. 
	 	게시판 한페이지에는 15개의 게시물을 보여줄 수 있다. 게시물이 없더라도 한페이지는 필요
	 	게시물의 갯수를 랜덤하게 발생시켜서 
	 	페이지가 몇개가 필요한지 출력해주는 프로그램을 작성하세요.
	 */
	public static void main(String[] args) {
		int num = (int)(Math.random()*100);// 0부터 99
		int board = 0;
		if(num==0){
			board = 1;		
		}
		else {
			if(num%15==0) {
				board = num/15;
			}
			else {
				board = num/15+1;
			}
			
		}
				
		System.out.println(" 게시물 갯수가 "+num+"개이고 "+board+"페이지가 필요하당");
	}
	

}
