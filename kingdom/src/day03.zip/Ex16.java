package day03;

public class Ex16 {
	/*
	반복문을 사용해서 다음 형태로 숫자를 출력하세요.
	
	1. 
		1
		1  2
		1  2  3
		1  2  3  4
		1  2  3  4  5
		
		
	2. 
		 1  2  3  4  5
		 6  7  8  9 10
		11 12 13 14 15
		16 17 18 19 20
		21 22 23 34 25
		
	3. 
		 1
		 2  3
		 4  5  6
		 7  8  9 10
		11 12 13 14 15
		
	4.
		 1  2  3  4  5
		10  9  8  7  6
		11 12 13 14 15
		20 19 18 17 16
		21 22 23 24 25
		 
	
 */

	public static void main(String[] args) {
		
		System.out.println("1. ");
		for(int i=1;i<6;i++) {
			for(int j=1;j<i+1;j++) {
				System.out.print(j+" ");
			}
			System.out.println("");
		}	
		
		System.out.println("2. ");
		int first = 0;
		for(int i=1;i<6;i++) {
			for(int j=1;j<6;j++) {
				if(first <10) System.out.print((first+j)+"  ");
				else System.out.print(first+j+" ");
			}
			System.out.println("");
			first = first +5;
		}
		
		System.out.println("3. ");
		int num = 1;
		for(int i=1;i<6;i++) {
			for(int j=0;j<i;j++) {
				System.out.print(num+" ");
				num++;
			}			
			System.out.print("\n");
		}
		
		System.out.println("4. ");
		int second = 0;
		for(int i=1;i<6;i++) {
			if(i%2!=0) {
				for(int j=1;j<6;j++) {
					System.out.print(second+j+" ");
				}
			}
			else {
				for(int j=5;j>0;j--){
					System.out.print(second+j+" ");
				}
			}
			System.out.println("");
			second = second + 5;
		}

		}
	
			
	
}
