package day03;
import java.util.Scanner;
public class Ex07 {
	/*
	 	랜덤하게 두자리 숫자를 만들어서
	 	그 숫자를 사용자가 맞추는 게임을 만드세요.
	 	
	 	option ]
	 		1. 10회내에 맞추지 못하면 게임이 종료
	 		2. 맞출때까지 
	 		3. 입력한숫자가 큰수인지 작은수인지 알려주면서 게임을 진행하기
	 */
	public static void main(String[] args) {
		int num1 = (int)(Math.random()*90)+10;
		int num2 = 0;
		int cnt = 0;
		
		while(cnt < 10) {
			System.out.print("두자리 숫자를 입력해보세용 : ");
			Scanner sc = new Scanner(System.in);
			num2 = sc.nextInt();
			if(num1>num2) {
				System.out.println("그거보단 커요!!");
			}
			else if(num1<num2) {
				System.out.println("그거보단 작아요!!");
			}
			else {
				System.out.println("정답입니당!!");
				break;
			}
			cnt++;
			
		}
		
		if(cnt==10 && num1!=num2){
			System.out.println("실패하셨습니당 ㅠㅠ");
		}
	}

}
