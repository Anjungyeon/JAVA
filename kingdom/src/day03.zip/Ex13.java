package day03;
import java.util.Scanner;
public class Ex13 {
	
	/*
	정수를 입력받아서
	0부터 입력받은 정수까지의 합을 계산해주는 프로그램을 작성하세요.
 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		sc.close();
		int res = 0;
		
		for (int i=0;i<num+1;i++) {
			res = res + i;
		}
		
		System.out.println("합 : "+res);
	}

}
