package day03;

import java.util.Scanner;
public class Ex01 {
	/*
	 	정수를 입력받아서
	 	가장 가까운 10의 배수와 입력한 수와의 차를 출력하는 프로그램을 작성하세요.
	 */
	public static void main(String[] args) {
		
		System.out.println("정수를 입력하세요 : ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int res = 0;
		int tmp = 0;
		sc.close();
		
		if(num%10==0) {
			res = num;
		}
		else {
			if(num%10>=5) {
				tmp = (num/10)+1;
				res = tmp*10;				
			}
			else {
				tmp = (num/10);
				res = tmp*10;	
			}
			
			
		}
		System.out.println("입력한 수 "+num+"와 가장 가까운 10의 배수는 "+res+"입니당");
		
	}
}
