package day03;

public class Test01 {
	/*
	 	제어문의 경우 블럭내의 명령이 한개인 경우는 블럭기호를 생략할수 있다.
	 */
	public static void main(String[] args) {
		if(1==1) {
			System.out.println("앙");
		}
		if(1==1) System.out.println("앙");
	}
}
