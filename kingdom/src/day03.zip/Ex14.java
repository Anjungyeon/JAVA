package day03;

import java.util.Scanner;

public class Ex14 {
	/*
	정수를 입력받아서
	그 정수까지의 펙토리얼을 계산해주는 프로그램을 작성하세요.
	
	참고 ]
		펙토리얼(!) : 1 부터 특정수까지의 곱
		
		예 ]
			5!
			==> 	1 * 2 * 3 * 4 * 5
 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int res = 1;
		
		for (int i=1;i<=num;i++) {
			res = res * i;
		}
		
		System.out.println("곱 : "+res);
	}

}
