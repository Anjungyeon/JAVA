package day03;

public class Ex10 {
	/*
	반장님과 제가 학교를 한바퀴 구경합니다.
	반장님은 정문에서 오른쪽으로 1.07m/s
	저는 정문에서 왼쪽으로 구경을 하는데	0.54m/s
	로 구경한다.
	
	반장님과 저는 몇초후 만나게 되는지 출력해주는 프로그램을 작성하세요.
	 
	 학교 한바퀴는 5475m 라고 가정한다.
	 
	 반복문으로 해결하세요.
 */
	public static void main(String[] args) {
		double vB = 1.07;
		double vT = 0.54;
		
		for (int t =0;;t++) {
			if((vB*t)+(vT*t)>=5475) {
				System.out.println(t+"초 만에 반장님과 내가 만났습니당!!");
				break;
			}
		}
	}

}
