package day03;

public class Ex08 {
	/*
	정수 5자리 숫자를 랜덤하게 발생한 후
	각자리의 수를 합한 결과를 출력해주는 프로그램을 작성하세요.
 */
	public static void main(String[] args) {
		int num = (int)(Math.random()*90000)+10000;
		int num1 = num;

		int no1 = 0;
		int no2 = 0;
		int no3 = 0;
		int no4 = 0;
		int no5 = 0;
		
		no5 = num%10; // 1의자리
		num = num - no5;
		
		no4 = num%100; // 10 의자리
		num = num - no4;
		no4 = no4/10;
		
		no3 = num%1000; // 100의자리
		num = num - no3;
		no3 = no3/100;
		
		no2 = num%10000; // 1000의 자리
		num = num - no2;
		no2 = no2/1000;
		
		no1 = num%100000; // 10000의자리
		num = num - no1;
		no1 = no1/10000;
		
		int res = 0;
		res = no1+no2+no3+no4+no5;
		
		System.out.println(num1+"의 각 자리수를 더한 값은 " +res+"입니당");
	}

}
