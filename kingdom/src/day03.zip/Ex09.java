package day03;

import java.util.Scanner;

public class Ex09 {
	/*
	 	숫자형식의 문자열을 입력한후
	 	각 자리수들의 합을 구하는 프로그램 작성.
	 	
	 	참고 ] 
	 		문자열의 길이를 알려주는 함수 : 문자열.length()
	 		
	 		특정 위치의 문자 반환해주는 함수 : 문자열.charAt(위치값) 
	 		문자열의 특정문자의 위치값 반환해주는 함수 : 문자열.indexOf(문자)
	 		
	 	단, 문자열 전체를 정수로 변환해서 계산하는 방법을 피한다.
	 	
	 */
	public static void main(String[] args) {
		System.out.println("각 자리의 합을 구할 숫자를 입력하세요. :");
		Scanner sc = new Scanner(System.in);
		String num = sc.next();
		int len = num.length();

		int res =0;
		
		
		for(int i=0;i<len;i++) {
			res = res + ((int)(num.charAt(i))-'0');
			
		}
		System.out.println("각 자리의 합은 : "+res);
	}
}
