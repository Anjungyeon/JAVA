package day03;

import java.util.Scanner;

public class Ex15 {
	public static void main(String[] args) {
		/*
		다음 모양으로 * 를 사용해서 출력하세요.
		
		
		1. 
			*****
			*****
			*****
			*****
			*****
		
		2. 
			 *
			 **
			 ***
			 ****
			 *****
		
		3.     *
			  **
			 ***
			****
		   *****
		   
		4. 
			 *****
			 ****
			 ***
			 **
			 *
			 
		5. 
			*****
			 ****
			  ***
			   **
			    *
		EXTRA ]
		
	 */
		
		System.out.println("1. ");
		for(int i=0;i<5;i++) {
			System.out.println("* * * * *");
		}
		
		System.out.println("2. ");
		for(int i=1;i<6;i++) {
			for(int j=0;j<i;j++) {
				System.out.print("* ");
			}			
			System.out.print("\n");
		}
		
		System.out.println("3. ");
		for(int i=1;i<6;i++) {
			for(int j=5;j>0;j--) {		
				if(i<j){
					System.out.print("  ");
					}
				else{
					System.out.print("* ");
					}
				}			
			System.out.print("\n");
		}
		
		System.out.println("4. ");
		for(int i=0;i<5;i++) {
			for(int j=5;j>i;j--) {
				System.out.print("* ");
			}			
			System.out.print("\n");
		}
		
		System.out.println("5. ");
		for(int i=1;i<6;i++) {
			for(int j=1;j<6;j++) {		
				if(i<=j){
					System.out.print("* ");
					}
				else{
					System.out.print("  ");
					}
				}			
			System.out.print("\n");
		}
		
		System.out.println("EXTRA 1. ");
		System.out.println("홀수를 입력해듀대용 : ");
		Scanner sc = new Scanner(System.in);
		
		int no = sc.nextInt();
		sc.close();
		int star = 0;
		// 위삼각형
		for(int i = 0;i<no;i+=2){
			
			for(int j=no;j>=i;j-=2) { //별앞에 공백
				System.out.print("  ");				
			}
			for(star=0;star<=i;star++) {
				System.out.print("* ");
			}
			System.out.println("");			
		}
		// 아래 삼각형 위에꺼랑 반대롱
		for(int i=0;i<no-2;i+=2)//한줄 적게 출력되기때문에 2씩증가하므로 2를 빼버림
			{
				for(int j=0;j<=i+2;j+=2) {
					System.out.print("  ");		
				}
				for(star =no-2;star>i;star--) // 가운데줄 빼고 시작하니까 2빼고 시작
				{
					System.out.print("* ");
				}
				System.out.println("");
			}
	}
	

}
