package day06;

public class Test02 {
	int no = 10;
	public void abc() {
		System.out.println("##이 클래스는 Test02 클래스 ##");
	}
}
