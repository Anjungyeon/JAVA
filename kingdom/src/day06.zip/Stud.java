package day06;

public class Stud {
	public static String ex;
	public int studno, java,db, js,jsp,spring,total;
	public double avg;
	public String name;
	private int grade;
	
	public Stud() {
	}
	
	// 생성자 오버로딩
	public Stud(String name) {
		/*
			this :
				현재 실행중인 객체 자기자신을 가리키는 예약어
		 */
		this.name = name;
	}
	
	public Stud(String name, int studno) {
		this.name = name;
		this.studno = studno;
		
	}
	
	public Stud(String name, int studno,int java, int db,int js, int jsp, int spring) {
		this(name,studno); //this()는 생성자함수의 첫줄 첫문장이어야 한다.
		this.java = java;
		this.db=db;
		this.js = js;
		this.jsp = jsp;
		this.spring = spring;
		setTotal();
		setAvg();
	}
	
	public void setTotal(int total) {
		this.total = total;
	}
	
	public void setTotal() {
		total = java+db+jsp+js+spring;
	}
	
	public void setAvg() {
		avg = total/5.; // 5를 쓰면 정수연산을해서 소숫점이 짤려버린다.
	}
	
	public int getGrade() {
		return this.grade;
	}
	
	public void setGrade(int g) {
		this.grade = g;
	}
	// 출력하는 기능의 함수
	public void toPrint() {
		System.out.printf("[ %2d ] %8s - %3d, %3d, %3d ,%3d, %3d, %3d, %4.2f\n", studno,name,java,db,js,jsp,spring,total,avg);
	}

}
