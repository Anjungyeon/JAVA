package day06;

public class Test01 {
	public static void main(String[] args) {
		Data d1 = new Data();
		Object o1 = d1;
		
		Object[] obj= {"제니","blackpink",20,170.0};
	}
	

}
