package day06.ex;

public class Nemo extends Figure {
	private int garo,sero;
	private int area;
	
	public Nemo() {}
	public Nemo(int garo,int sero) {
		this.garo = garo;
		this.sero = sero;
		getArea();
	}
	public int getArea() {
		area = garo * sero;
		return area;
	}
	
	public void toPrint() {
		System.out.printf("네모	- 가로	:	%3d,세로 :	%3d,	면적 :	%4d\n",
								garo,sero,area);
	}

}
