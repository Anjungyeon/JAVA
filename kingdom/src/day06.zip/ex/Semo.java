package day06.ex;

public class Semo extends Figure {
	private int height,bottom;
	private double area;
	
	public Semo() {}
	
	public Semo(int height,int bottom) {
		this.height = height;
		this.bottom = bottom;
		getArea();
	}
	
	public double getArea() {
		area = height * bottom * 0.5;
		return area;
	}
	
	public void toPrint() {
		System.out.printf("세모	- 가로	:	%3d,세로 :	%3d,	면적 :	%.2f\n",
				bottom,height,area);
	}

}
