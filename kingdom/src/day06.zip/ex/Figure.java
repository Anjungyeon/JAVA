package day06.ex;

public class Figure {
	public void toPrint() {
		System.out.println("모양");
	}

}
