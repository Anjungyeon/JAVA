package day06.ex;

public class Circle extends Figure {
	private int rad;
	private double area,arround;
	
	public Circle() {}
	public Circle(int rad) {
		this.rad = rad;
		getArround();
		getArea();
	}
	
	public double getArround() {
		arround = rad * 2 * 3.14;
		return arround;
	}
	
	public double getArea() {
		area = rad * rad * 3.14;
		return area;
	}
	
	public void toPrint() {
		System.out.printf("원	- 반지름:	%3d,둘레 :	%.2f,	면적 :	%.2f\n",
				rad,arround,area);
	}

}
