package day06.ex;
/*
 	Figure클래스를 상속받은 Nemo, Semo, Circle 클래스를 만들고 필요한 함수는 재정의해서 다음의 형태로 출력하는 프로그램을 작성하세요
 	랜덤하게 숫자를 발생시켜서
 		0 - Circle
 		1 - Semo
 		2 - Nemo
 	가 기억되도록 하나의 변수에 10개를 기억시켜서 --> 배열 이용 
 	출력해주세요
 	
 	출력형태 
 		네모	- 가로 : XXX , 세로 : XXX , 면적 : XXX
 		원		- 반지름 : XXX, 둘레 : XXX, 면적 : XXX
 		
 	단, 필요한 데이터는 그 클래스가 객체가 되는 순간 기억되도록 작성하세요. --> 생성자에서 초기화를 해주세요
 	
 */

public class Ex01 {
	public static void main(String[] args) {
		Figure fig[] = new Figure[10];
		
		for(int i = 0;i<10;i++) {
			int no = (int)(Math.random()*3);
			if(no==0) {
				fig[i] = new Circle((int)(Math.random()*21)+5);
			}
			else if(no == 1) {
				fig[i] = new Semo((int)(Math.random()*21)+5,(int)(Math.random()*21)+5);
			}
			else {
				fig[i] = new Nemo((int)(Math.random()*21)+5,(int)(Math.random()*21)+5);
			}
		}
		
		for(Figure read:fig) {
			read.toPrint();
		
		}
	}

}
