package day06;

public class Won extends Shap{
	// 변수 선언 추가
	private int rad;
	private double arround,area;
	
	public Won() {}
	
	public Won(int rad) {
		this.rad = rad;
		setArround();
		getArea();
	}
	
	// 함수추가
	public void setArround() {
		arround = 2 * rad * 3.14;
	}
	// overriding
	
	public double getArea() {
		area = rad * rad * 3.14;
		return area;
	}

}
