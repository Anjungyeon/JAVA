package day06;

public class Test02_02 extends Test02 {
	public void abc() {
		System.out.println("### 여기는 Test02_02 ###");
	}
	

}
