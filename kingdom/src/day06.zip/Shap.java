package day06;

public class Shap {
	
	public double getArea() {
		return 0.0;
	}
	public void toPrint() {
		System.out.println("원");
		
	}

}
