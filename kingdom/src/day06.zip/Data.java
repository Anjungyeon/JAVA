package day06;

public class Data {
	private int num0;
	int num1 ; // 같은 패키지일경우 사용가능
	protected int num2; // 상속받은 하위 클래스이거나 같은패키지
	public int num3;

}
